if(findd(s))
    // {
    //     cout<<"PRESENT\n";
    // }
    // else
    // {
    //     cout<<"NOT PRESENT\n";
    // }